
import React from "react";

export default function CafeChecklistApp() {
  return (
    <div style={{ padding: 20 }}>
      <img src="/image.png" alt="Xpresso Logo" style={{ width: 100, marginBottom: 20 }} />
      <h1>Xpresso Store Audit Checklist</h1>
      <p>This is a placeholder. Full logic will be implemented here.</p>
    </div>
  );
}
